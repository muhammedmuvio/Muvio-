package com.muvio.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF0B0B10)
private val Card = Color(0xFF15151D)
private val Accent = Color(0xFF7C5CFC)
private val Muted = Color(0xFF9B9BA7)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MuvioApp() }
    }
}

@Composable
fun MuvioApp() {
    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Card, primary = Accent, onBackground = Color.White
    )) { MuvioHome() }
}

@Composable
fun MuvioHome() {
    var selected by remember { mutableStateOf(0) }
    val stories = listOf("Your story", "Aisha", "Daniel", "Mimi", "Tobi")
    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF111117)) {
                val items = listOf(
                    Icons.Default.Home to "Home", Icons.Default.Search to "Search",
                    Icons.Default.AddCircle to "Create", Icons.Default.Notifications to "Alerts",
                    Icons.Default.Person to "Profile"
                )
                items.forEachIndexed { i, pair ->
                    NavigationBarItem(
                        selected = selected == i,
                        onClick = { selected = i },
                        icon = { Icon(pair.first, contentDescription = pair.second) },
                        label = { Text(pair.second, fontSize = 10.sp) }
                    )
                }
            }
        }
    ) { pad ->
        Column(Modifier.fillMaxSize().background(Bg).padding(pad)) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Muvio", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold,
                    color = Color.White)
                Spacer(Modifier.weight(1f))
                IconButton(onClick = {}) { Icon(Icons.Default.FavoriteBorder, "Likes") }
                IconButton(onClick = {}) { Icon(Icons.Default.Send, "Messages") }
            }

            LazyRow(
                contentPadding = PaddingValues(horizontal = 18.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(stories) { name ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            Modifier.size(64.dp).clip(CircleShape).background(
                                Brush.linearGradient(listOf(Accent, Color(0xFFEF4B8A)))
                            ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(name.take(1), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(name, color = Color.White, fontSize = 11.sp)
                    }
                }
            }

            Spacer(Modifier.height(18.dp))

            Card(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Card)
            ) {
                Column(Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(42.dp).clip(CircleShape).background(Accent),
                            contentAlignment = Alignment.Center) {
                            Text("M", fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("Muvio Official", fontWeight = FontWeight.Bold)
                            Text("Trending now", color = Muted, fontSize = 12.sp)
                        }
                        Spacer(Modifier.weight(1f))
                        Icon(Icons.Default.MoreVert, "More")
                    }
                    Spacer(Modifier.height(14.dp))
                    Box(
                        Modifier.fillMaxWidth().height(230.dp).clip(RoundedCornerShape(18.dp))
                            .background(
                                Brush.linearGradient(
                                    listOf(Color(0xFF251B4B), Color(0xFF12121A), Color(0xFF47213F))
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Discover more.", fontSize = 27.sp,
                                fontWeight = FontWeight.ExtraBold)
                            Text("Create • Connect • Earn", color = Color.LightGray)
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.FavoriteBorder, "Like")
                        Spacer(Modifier.width(18.dp))
                        Icon(Icons.Default.ChatBubbleOutline, "Comment")
                        Spacer(Modifier.width(18.dp))
                        Icon(Icons.Default.Send, "Share")
                        Spacer(Modifier.weight(1f))
                        Icon(Icons.Default.BookmarkBorder, "Save")
                    }
                    Spacer(Modifier.height(10.dp))
                    Text("Build your audience and turn your creativity into opportunities.",
                        color = Color.White, fontSize = 14.sp)
                }
            }
        }
    }
}
